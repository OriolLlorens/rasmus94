<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Reggae+One&display=swap" rel="stylesheet">

    <style>
        body {
            /* background-image: url(chat6.1111.jpg); */
            background-image: url('Imgchat7.111.jpg');
            font-family: 'Reggae One', cursive;
            /* background: url('Img/chat.jpg'); */
            height: 50vh;
	        background-size: cover;
	        /* background-position: center; */
            
        }

        ul {
            display: flex;
            flex-direction: row-reverse;
            /* border: 2px solid red; */
            /* padding: 2px;
            border-radius: 5px; */
            margin: 30px;
            /* width: 500px; */
        }

        .item a {
            /* border: 2px solid red; */
            width: 320px;
            text-decoration: none;
            margin: 30px;
            padding: 10px;
            color: rgb(22, 12, 12);
            font-size:large;


        }

        .item {
            list-style: none;
        }

        .item a:hover {
            color: rgb(236, 229, 229);
            background-color: black;
            border-radius: 10px;
        }
        .con1{
            /* display: flex;
            flex-direction: column; */
            color: rgb(10, 11, 12);
            /* border: 2px solid red; */
            padding: 130px;
            text-align: center;
            /* justify-content: center; */
        }
        /* .logo{
            height: 30px;
            width: 30px;
            opacity: 0.4;
        } */
        .con1 h4{
            color: rgb(8, 6, 6);
        }
        .con1 h3{
            color: rgb(17, 10, 10);
        }
        
    </style>

<body>
    <nav id="navbar">
        <ul class="con">
            <li class="item"><a href="../vista/registro.php">Registrate</a></li>
            <li class="item"><a href="../vista/login.php">Inicia Sesión</a></li>
        </ul>
    </nav>
    <section class="sec" id="se">
        <div class="con1">
            <h3>Bienvenido</h3>

            <h1>
                Aplicación de horarios
            </h1>
        </div>
    </section>
</body>

</html>