<?php 
session_start();
require_once '../config/config.php';
require_once BASE_PATH .'/includes/auth_validate.php';

$codigo = filter_input(INPUT_POST, 'del_id');

// recibe el parámetro $codigo a borrar
if ($codigo && $_SERVER['REQUEST_METHOD'] == 'POST') {
	//if($_SESSION['admin_type']!='super'){
    if($_SESSION['esAdmin']!=1) {
		$_SESSION['failure'] = "No se tienes permisos para esta acción.";
    	header('location: index.php');
        exit;
	}
    //$codigo = $del_id;

    $db = getDbInstance();
    $db->where('id', $codigo);
    $status = $db->delete('students');
    
    if ($status) {
        $_SESSION['info'] = "Estudiante borrado de la BD!";
    }
    else {
    	$_SESSION['failure'] = "Error al borrar estudiante";
    }
    header('location: students.php');
    exit;
}