<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_validate.php';

/*   S O L O    A D M I N   */

    if ($_SESSION['esAdmin']==1) {
        // si es administrador el que edita lo envía aquí por GET
        $codigo = filter_input(INPUT_GET, 'id_schedule',FILTER_SANITIZE_STRING); // FILTER_VALIDATE_INT);
        $operation = filter_input(INPUT_GET, 'operation',FILTER_SANITIZE_STRING);
        ($operation == 'edit') ? $edit = true : $edit = false;
    } else {header('location: index.php');exit;}

$db = getDbInstance();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data_to_store = array_filter($_POST);

    if ($edit) {
        $db->where('id_schedule', $codigo);
        $stat = $db->update('schedule', $data_to_store);

        if ($stat) {
            $_SESSION['success'] = "Horario actualizado!";
        }
        else {
            $_SESSION['failure'] = "El horario no se ha actualizado!";
        }
    } else  {
        //$data_to_store = array_filter($_POST);
        $last_id = $db->insert('schedule', $data_to_store);
        if($last_id) {
            $_SESSION['success'] = "Horario añadido!";
        }
        else {
            $_SESSION['failure'] = "El horario no se ha añadido!";
            //header('location: enrollments.php');
            //echo 'fallo al insertar clase: ' . $db->getLastError();
            //exit();
        }
    }
    header('location: horarios_clases.php');
    exit();


}

//If edit variable is set, we are performing the update operation.
$title='';
if($edit) {
    $title=$edit ? "Actualizar horario" : "Crear nuevo horario";
    $db->where('id_schedule', $codigo);
    //Get data to pre-populate the form.
    $schedule = $db->getOne("schedule");
}
// Get data to pre-populate the form.

$rowClases=$db->get("class");

require_once BASE_PATH .'/includes/header_courses.php';
?>

<div id="page-wrapper">
<div class="row">
     <div class="col-lg-12">
            <h2 class="page-header"> <?php  echo $title ?></h2>
        </div>
</div>
    <form class="form" action="" method="post"  id="enrollment_form" enctype="multipart/form-data">
       <?php  include_once('../forms/schedule_form.php'); ?>
    </form>
</div>

<script type="text/javascript">
$(document).ready(function(){
   $("#enrollment_form").validate({
       rules: {
            status: {
                required: true
            }
        }
    });
});
</script>

<?php include_once '../includes/footer.php'; ?>