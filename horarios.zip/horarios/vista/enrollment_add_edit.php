<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_validate.php';

/*   S O L O    A D M I N   */

    if ($_SESSION['esAdmin']==1) {
        // si es administrador el que edita lo envía aquí por GET
        $codigo = filter_input(INPUT_GET, 'id_enrollment',FILTER_SANITIZE_STRING); // FILTER_VALIDATE_INT);
        $operation = filter_input(INPUT_GET, 'operation',FILTER_SANITIZE_STRING);
        ($operation == 'edit') ? $edit = true : $edit = false;
    } else {header('location: index.php');exit;}

$db = getDbInstance();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data_to_store = array_filter($_POST);

    if ($edit) {
        $db->where('id_enrollment', $codigo);
        $stat = $db->update('enrollment', $data_to_store);

        if ($stat) {
            $_SESSION['success'] = "Matrícula actualizada!";
        }
        else {
            $_SESSION['failure'] = "El estudiante ya esta matriculado en ese curso. Entrada duplicada!";
        }
    } else  {
        //$data_to_store = array_filter($_POST);
        $last_id = $db->insert('enrollment', $data_to_store);
        if($last_id) {
            $_SESSION['success'] = "Matrícula añadida!";
        }
        else {
            $_SESSION['failure'] = "El estudiante ya esta matriculado en ese curso. Entrada duplicada!";
            //header('location: enrollments.php');
            //echo 'fallo al insertar clase: ' . $db->getLastError();
            //exit();
        }
    }
    header('location: enrollments.php');
    exit();


}

//If edit variable is set, we are performing the update operation.
$title='';
if($edit) {
    $title=$edit ? "Actualizar Matrícula" : "Crear nueva matrícula";
    $db->where('id_enrollment', $codigo);
    //Get data to pre-populate the form.
    $enrollment = $db->getOne("enrollment");
}
// Get data to pre-populate the form.
$rowEstudiantes=$db->get("students");
$rowCursos=$db->get("courses");

require_once BASE_PATH .'/includes/header_courses.php';
?>

<div id="page-wrapper">
<div class="row">
     <div class="col-lg-12">
            <h2 class="page-header"> <?php  echo $title ?></h2>
        </div>
</div>
    <form class="form" action="" method="post"  id="enrollment_form" enctype="multipart/form-data">
       <?php  include_once('../forms/enrollment_form.php'); ?>
    </form>
</div>

<script type="text/javascript">
$(document).ready(function(){
   $("#enrollment_form").validate({
       rules: {
            status: {
                required: true
            }
        }
    });
});
</script>

<?php include_once '../includes/footer.php'; ?>