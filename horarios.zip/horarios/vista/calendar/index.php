<?php
/*require_once('bdd.php');
include('../functions.php');*/


session_start();
require_once '../../config/config.php';
require_once BASE_PATH . '/includes/auth_validate.php';

//Get DB instance. function is defined in config.php
$db = getDbInstance();
//Get Dashboard information
if (isset($_SESSION['id_student'])) {
}

$events = DAOCourses::obtenerCalendario($_SESSION['id_student']);

?>
<?php include_once('../../includes/header_courses.php'); ?>
<!--<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Calendario</title>
-->    <!-- Bootstrap Core CSS -->
    <!--<link href="css/bootstrap.min.css" rel="stylesheet">-->
    <!-- FullCalendar -->
    <!--<link href='css/fullcalendar.css' rel='stylesheet'/>-->
    <!-- Custom CSS -->
    <!--<style>
        #calendar { max-width: 800px; }
        .col-centered { float: none; margin: 0 auto; }
    </style>-->
<!--</head>
<body>
-->
<!-- Navigation -->
<?php if (isset($_SESSION['user_logged_in'])) : ?>
    <?php
    $db->where('id',$_SESSION['id_student']);
    $student=$db->getOne('students');

    $user = $student['username'];
    $name = $student['name'];
    $surname = $student['surname'];
    $email = $student['email'];
    ?>


    <?php /*include('./navbarCalendar.php'); */?>

    <!-- Page Content -->
    <div id="page-wrapper">

    <!--   C A L E N D A R I O   -->
        <div class="row">
            <div class="col-lg-12 text-center">
                <h1>Programación de estudiante Calendario</h1>
                <p class="lead">Aquí podrás consultar los horarios de las asignaturas donde te has inscrito</p>
                <div id="calendar" class="col-centered">
                </div>
            </div>

        </div>
        <!-- /.row -->

    </div>
    <!-- /.container -->
    <?php include_once('../../includes/footer.php'); ?>

    <!-- jQuery Version 1.11.1 -->
   <!-- <script src="js/jquery.js"></script>-->

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- FullCalendar -->
    <script src='js/moment.min.js'></script>
    <script src='js/fullcalendar/fullcalendar.min.js'></script>
    <script src='js/fullcalendar/fullcalendar.js'></script>
    <script src='js/fullcalendar/locale/es.js'></script>


    <script>
        $(document).ready(function () {
            var date = new Date();
            var yyyy = date.getFullYear().toString();
            var mm = (date.getMonth() + 1).toString().length == 1 ? "0" + (date.getMonth() + 1).toString() : (date.getMonth() + 1).toString();
            var dd = (date.getDate()).toString().length == 1 ? "0" + (date.getDate()).toString() : (date.getDate()).toString();

            $('#calendar').fullCalendar({
                header: {
                    language: 'es',
                    left: 'prev,next today',
                    center: 'title',
                    right: 'month,basicWeek,basicDay',

                },
                defaultDate: yyyy + "-" + mm + "-" + dd,
                editable: false,
                eventLimit: true, // allow "more" link when too many events
                selectable: true,
                selectHelper: true,
                select: function (start, end) {

                    $('#ModalAdd #start').val(moment(start).format('YYYY-MM-DD HH:mm:ss'));
                    $('#ModalAdd #end').val(moment(end).format('YYYY-MM-DD HH:mm:ss'));
                    $('#ModalAdd').modal('show');
                },
                eventRender: function (event, element) {
                    element.bind('dblclick', function () {
                        $('#ModalEdit #id').val(event.id);
                        $('#ModalEdit #title').val(event.title);
                        $('#ModalEdit #color').val(event.color);
                        $('#ModalEdit').modal('show');
                    });
                },
                eventDrop: function (event, delta, revertFunc) { // si changement de position
                    edit(event);
                },
                eventResize: function (event, dayDelta, minuteDelta, revertFunc) { // si changement de longueur
                    edit(event);
                },
                events: [
                    <?php
                    $i = 0;
                    foreach($events as $event){
                    ?>
                    {
                        start: '<?php echo $event["day"]."T".$event["time_start"] ?>',
                        end: '<?php echo $event["day"]."T".$event["time_end"] ?>',
                        title: '<?php echo $event["name"]; ?>',
                        id: '<?php echo $i; ?>',
                        color: '<?php echo $event["color"]; ?>',
                    }
                    ,
                    <?php
                    $i++;
                    }
                    ?>
                ]
            })
            ;

        });

    </script>
<?php endif ?>
</body>

</html>
