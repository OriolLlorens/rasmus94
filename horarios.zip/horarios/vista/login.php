<?php
session_start();
require_once '../config/config.php';

// If User has already logged in, redirect to dashboard page.
if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === TRUE) {
	header('Location:index.php');
}


include BASE_PATH.'/includes/header_courses.php';
?>
<div id="page-" class="col-md-4 col-md-offset-4">
	<form class="form loginform" method="POST" action="authenticate.php">
		<div class="login-panel panel panel-default">
			<div class="panel-heading">Login Producto 2. Aplicación de
                creación de horarios escolares </div>
			<div class="panel-body">
				<div class="form-group">
					<label class="control-label">Nombre de usuario</label>
                    <!--<input type="checkbox" name="admin" value="esAdmin"> Es administrador</input>-->
                    <div class="form-check">
                        <input name="admin" class="form-check-input" type="checkbox" value="esAdmin" id="flexCheckChecked">
                               <!--checked>-->
                        <label class="form-check-label" for="flexCheckChecked">
                            Es administrador (admin |1234)
                        </label>
                    </div>
                    <!--<input type="checkbox" name="admin" value="noEsAdmin">Sólo estudiante</input>-->
					<input type="text" name="username" value="juan" class="form-control" required="required">
				</div>
				<div class="form-group">
					<label class="control-label">Clave</label>
					<input type="clave" name="pass" value="1234" class="form-control" required="required">
				</div>

                <a href="registro.php">
                    <div class="panel-footer">
                        <span class="pull-left">Registrarse</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>

				<!--<div class="checkbox">
					<label>
						<input name="remember" type="checkbox" value="1">Remember Me
					</label>
				</div>-->
				<?php if (isset($_SESSION['login_failure'])): ?>
				<div class="alert alert-danger alert-dismissable fade in">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<?php
					echo $_SESSION['login_failure'];
					unset($_SESSION['login_failure']);
					?>
                    <!--<a href="/registro.php" >registrarse</a>-->
                    <?php
/*                    echo $_SESSION['login_failure'];
                    unset($_SESSION['login_failure']);
                    */?>
				</div>
				<?php endif; ?>
                <?php if (isset($_SESSION['success'])) { ?>
                    <div class="alert alert-success alert-dismissable fade in">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <?php
                        echo $_SESSION['success'];
                        unset($_SESSION['success']);
                        ?>
                    </div>
                <?php } ?>

                <br>
				<button type="submit" class="btn btn-success loginField">Login</button>
			</div>
		</div>
	</form>
</div>
<?php include BASE_PATH.'/includes/footer.php'; ?>
