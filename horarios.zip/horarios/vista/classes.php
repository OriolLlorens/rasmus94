<?php
session_start();
require_once '../config/config.php';
require_once BASE_PATH . '/includes/auth_validate.php';

/*
 * C. Panel administración: una vez se accede como administrador, tendrá acceso al Panel Administración donde podrá crear
nuevas asignaturas y cursos y conﬁgurar nuevas asignaturas en el horario. En este apartado se podrá conﬁgurar el día y hora
de las clases, el color, junto con el profesor que la imparte y el curso al que pertenece. Se dará la opción de poder añadir,
modiﬁcar y eliminar profesores, clases y cursos.
 * */


// model class
require_once BASE_PATH . '/vista/filtros/Clase.php';
setlocale(LC_ALL, "es_ES");
$table="class";
$codigo="id_class";
//$class = new HorarioClase();
$class = new Clase();

$search_string = filter_input(INPUT_GET, 'search_string');
$filter_col = filter_input(INPUT_GET, 'filter_col');

// Si no hay filtro haré un select de todos los registros
if (!$filter_col) {	$filter_col = 'id_class'; $search_string=null;}

// E S T O   Y A   F U N C I O N A
if ($_SESSION['esAdmin'] == 1) {
    $rows=DAOCourses::itemsPorFiltroYWhere($table,null,null,$filter_col,$search_string);
    //$rows=DAOCourses::obtenerHorariosClasesPorEstudiante(null,null,$filter_col,$search_string);
} else {
    header('Location:login.php');
    exit;
}




include BASE_PATH . '/includes/header_courses.php';
?>
<!-- Main container -->
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-6">
            <h1 class="page-header">Gestión de clases</h1>
        </div>
        <div class="col-lg-6">
            <div class="page-action-links text-right">
                <a href="class_add_edit.php?operation=create" class="btn btn-success"><i class="glyphicon glyphicon-plus"></i> Añadir</a>
            </div>
        </div>
    </div>
    <?php include BASE_PATH . '/includes/flash_messages.php';?>

    <!-- Filters -->
    <div class="well text-center filter-form">
        <form class="form form-inline" action="">
            <label for="input_search">Buscar</label>
            <input type="text" class="form-control" id="input_search" name="search_string" value="<?php echo xss_clean($search_string); ?>">
            <label for="input_order">Por</label>
            <select name="filter_col" class="form-control">
                <?php
                foreach ($class->setOrderingValues() as $opt_value => $opt_name):
                    ($filter_col === $opt_value) ? $selected = 'selected' : $selected = '';
                    echo ' <option value="' . $opt_value . '" ' . $selected . '>' . $opt_name . '</option>';
                endforeach;
                ?>
            </select>
            <input type="submit" value="Filtrar" class="btn btn-primary">
        </form>
    </div>
    <hr>
    <!-- //Filters -->

    <!-- Table -->
    <table class="table table-striped table-bordered table-condensed">
        <thead>
            <tr><!-- id_class id_teacher id_course id_schedule name color -->
                <th>id Clase</th>
                <th>id Profesor</th>
                <th>id Curso</th>
                <th>id Programación</th>
                <th>Nombre</th>
                <th>Color</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $row): ?>
            <!--
            id_enrollment`            id_student            id_course            status
            id_course            name            description            date_start            date_end            active
            id_class            id_teacher            id_course            id_schedule            name            color
            id_schedule            id_class            time_start            time_end            day
            -->
            <tr>
                <td aria-disabled="true"><?php echo $row[$codigo]; ?></td>
                <td><?php echo xss_clean(($row['id_teacher'])) ?></td>
                <td><?php echo xss_clean($row['id_course']); ?></td>
                <td><?php echo xss_clean($row['id_schedule']); ?></td>
                <td><?php echo xss_clean($row['name']); ?></td>
                <td><?php echo xss_clean($row['color']); ?></td>
                <td>
                    <a href="class_add_edit.php?id_class=<?php echo $row[$codigo]; ?>&operation=edit" class="btn btn-primary"><i class="glyphicon glyphicon-edit"></i></a>
                    <a href="#" class="btn btn-danger delete_btn" data-toggle="modal" data-target="#confirm-delete-<?php echo $row[$codigo]; ?>"><i class="glyphicon glyphicon-trash"></i></a>
                </td>
            </tr>
            <!-- Delete Confirmation Modal -->
            <div class="modal fade" id="confirm-delete-<?php echo $row[$codigo]; ?>" role="dialog">
                <div class="modal-dialog">
                    <form action="class_delete.php" method="POST">

                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">Confirmar</h4>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="del_id" id="del_id" value="<?php echo $row[$codigo]; ?>">
                                <p>Desea borrar la clase?</p>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-default pull-left">Sí</button>
                                <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!-- //Delete Confirmation Modal -->
            <?php endforeach;?>
        </tbody>
    </table>
    <!-- //Table -->
</div>
<!-- //Main container -->
<?php include BASE_PATH . '/includes/footer.php';?>
