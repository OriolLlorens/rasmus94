<?php
session_start();
require_once '../config/config.php';
require_once BASE_PATH . '/includes/auth_validate.php';

// model class
require_once BASE_PATH . '/vista/filtros/Course.php';


$table="courses";
$codigo="id_course";
$course = new Course();
$search_string = filter_input(INPUT_GET, 'search_string');
$filter_col = filter_input(INPUT_GET, 'filter_col');
if (!$filter_col) {
    $filter_col = $codigo;
    $search_string = null;
}

/*   T O D O S   V E N   T O D O S   L O S   C U R S O S */
//if ($_SESSION['esAdmin'] == 1) {
    $rows=DAOCourses::itemsPorFiltroYWhere($table,null,null,$filter_col,$search_string);
//} else {
//    $rows=DAOCourses::itemsPorFiltroYWhere($table,'id_student',$_SESSION['id_student'],$filter_col,$search_string);
    //$db->where("id_student", $_SESSION['id_student']);
//}







/*// Per page limit for pagination.
$pagelimit = 15;
// Get current page.
$page = filter_input(INPUT_GET, 'page');
if (!$page) {	$page = 1;}
// If filter types are not selected we show latest added data first
if (!$filter_col) {	$filter_col = 'codigo';}
if (!$order_by) {	$order_by = 'Desc';}
//Get DB instance. i.e instance of MYSQLiDB Library
$db = getDbInstance();
//$select = array('id', 'f_name', 'l_name', 'gender', 'phone', 'created_at', 'updated_at');
$select = array('codigo', 'imagen', 'descripcion', 'precio', 'existencias');
//Start building query according to input parameters.
// If search string
if ($search_string) {
	$db->where('precio', '%' . $search_string . '%', 'like');
	$db->orwhere('existencias', '%' . $search_string . '%', 'like');
}
//If order by option selected
if ($order_by) {	$db->orderBy($filter_col, $order_by);}
// Set pagination limit
$db->pageLimit = $pagelimit;
// Get result of the query.
$rows = $db->arraybuilder()->paginate('productos', $page, $select);
$total_pages = $db->totalPages;*/


include BASE_PATH . '/includes/header_courses.php';
?>
<!-- Main container -->
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-6">
            <h1 class="page-header">Cursos</h1>
        </div>
        <div class="col-lg-6">
            <div class="page-action-links text-right">
                <?php if ($_SESSION['esAdmin'] == 1) { ?>
                    <a href="course_add.php?operation=create" class="btn btn-success"><i class="glyphicon glyphicon-plus"></i> Añadir</a>
                <?php } else {  ?>
                    <a href="course_subscribe.php" class="btn btn-success"><i class="glyphicon glyphicon-plus"></i> Suscribirme</a>
                <?php } ?>
            </div>
        </div>
    </div>
    <?php include BASE_PATH . '/includes/flash_messages.php';?>

    <!-- Filters -->
    <div class="well text-center filter-form">
        <form class="form form-inline" action="">
            <label for="input_search">Buscar</label>
            <input type="text" class="form-control" id="input_search" name="search_string" value="<?php echo xss_clean($search_string); ?>">
            <label for="input_order">Por</label>
            <select name="filter_col" class="form-control">
                <?php
foreach ($course->setOrderingValues() as $opt_value => $opt_name):
	($filter_col === $opt_value) ? $selected = 'selected' : $selected = '';
	echo ' <option value="' . $opt_value . '" ' . $selected . '>' . $opt_name . '</option>';
endforeach;
?>
            </select>
            <input type="submit" value="Filtrar" class="btn btn-primary">
        </form>
    </div>
    <hr>
    <!-- //Filters -->


    <!--<div id="export-section">
        <a href="export_customers.php"><button class="btn btn-sm btn-primary">Export to CSV <i class="glyphicon glyphicon-export"></i></button></a>
    </div>-->

    <!-- Table -->
    <table class="table table-striped table-bordered table-condensed">
        <thead>
            <tr>
                <th>Codigo</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Inicio</th>
                <th>Fin</th>
                <th>Activo</th>
                <!--<th>Acciones</th>-->
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $row): ?>
            <tr>
<!--id_enrollment	id_student	id_course	status	id_course	name	description	date_start	date_end	active-->
                <td aria-disabled="true"><?php echo $row[$codigo]; ?></td>
                <td><?php echo xss_clean($row['name']); ?></td>
                <td><?php echo xss_clean(($row['description'])) ?></td>
                <td><?php echo xss_clean($row['date_start']); ?></td>
                <td><?php echo xss_clean($row['date_end']); ?></td>
                <td><?php echo xss_clean($row['active']); ?></td>
                <?php if ($_SESSION['esAdmin'] == 1) { ?>
                <td>
                    <a href="course_edit.php?id_course=<?php echo $row[$codigo]; ?>&operation=edit" class="btn btn-primary"><i class="glyphicon glyphicon-edit"></i></a>
                    <a href="#" class="btn btn-danger delete_btn" data-toggle="modal" data-target="#confirm-delete-<?php echo $row[$codigo]; ?>"><i class="glyphicon glyphicon-trash"></i></a>
                </td>
                <?php } ?>
            </tr>

            <!-- Delete Confirmation Modal -->
            <?php if ($_SESSION['esAdmin'] == 1) { ?>
            <div class="modal fade" id="confirm-delete-<?php echo $row[$codigo]; ?>" role="dialog">
                <div class="modal-dialog">
                    <form action="course_delete.php" method="POST">

                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">Confirmar</h4>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="del_id" id="del_id" value="<?php echo $row[$codigo]; ?>">
                                <p>Desea borrar el Curso?</p>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-default pull-left">Sí</button>
                                <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <?php } ?>
            <!-- //Delete Confirmation Modal -->

            <?php endforeach;?>
        </tbody>
    </table>
    <!-- //Table -->
</div>
<!-- //Main container -->
<?php include BASE_PATH . '/includes/footer.php';?>
