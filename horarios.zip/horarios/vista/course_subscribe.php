<?php
session_start();
require_once '../config/config.php';
require_once BASE_PATH . '/includes/auth_validate.php';

$db = getDbInstance();

$title="Suscripción a un curso";
// Get courses to show the student and helping to decide
$rowCursos=$db->get("courses");

//serve POST method, After successful insert, redirect to index.php page.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $data_to_update = filter_input_array(INPUT_POST);
    //Mass Insert Data. Keep "name" attribute in html form same as column name in mysql table.
    //$data_to_store = array_filter($_POST);

    //Insert id_student
    // Sanitize if you want //$id_course = filter_input(INPUT_GET, 'id_course', FILTER_VALIDATE_INT);

    //NO FUNCIONA $data_to_store += [ 'id_student' => strval($_SESSION('id_student')) ];
    // o también: $data_to_store += [ $_SESSION[0] ]; // parece que no

    /* *****
    * *vale $_SESSION: {id_student =>1, user_logged_in => true, esAdmin =>0}
    */

    //Insert status
    //$data_to_store['id_student'] =strval($_SESSION('id_student'));
    //Insert status
    //$data_to_store['status'] = 1;

    $db = getDbInstance();
    $db->where('id_student', $data_to_update['id_student']);
    $db->where('id_course', $data_to_update['id_course']);
    $row=$db->get('enrollment');

    if($row) {
        $_SESSION['failure'] = "matricula no añadida! Ya existe!";
        header('location: courses.php');
        //echo 'Estudiante ya tiene asignado ese curso. Insert failed: ' . $db->getLastError();
        exit();
    } else {

        $db->get('enrollment','id_student');
        $last_id = $db->insert('enrollment', $data_to_update);

        if($last_id) {
            $_SESSION['success'] = "matricula añadida!";
            header('location: courses.php');
            exit();
        }
        else {
            echo 'insert failed: ' . $db->getLastError();
            exit();
        }
    }
}


//We are using same form for adding and editing. This is a create form so declare $edit = false.
//$edit = false;
require_once BASE_PATH . '/includes/header_courses.php';
?>
<div id="page-wrapper">
<div class="row">
     <div class="col-lg-12">
            <h2 class="page-header">Suscripción a un curso</h2>
        </div>
        
</div>
    <form class="form" action="" method="post"  id="course_form" enctype="multipart/form-data">
       <?php  include_once('../forms/subscribe_course_form.php'); ?>
    </form>
</div>


<script type="text/javascript">
$(document).ready(function(){
   $("#course_form").validate({
       rules: {
            description: {
                required: true,
                minlength: 3
            }
            // ,precio: { required: true minlength: 3 },
        }
    });
});
</script>

<?php //include_once 'includes/footer.php'; ?>
<?php require_once BASE_PATH . '/includes/footer.php';?>
