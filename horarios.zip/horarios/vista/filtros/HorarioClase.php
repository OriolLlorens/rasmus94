<?php
class HorarioClase
{
    /**
     *
     */
    public function __construct()
    {
    }

    /**
     *
     */
    public function __destruct()
    {
    }
    
    /**
     * Set friendly columns\' names to order tables\' entries
     */
    public function setOrderingValues()
    {
        /*
         * ENROLLMENT id_enrollment`id_student id_course status
           COURSE id_course name description date_start date_end active
           CLASS id_class id_teacher id_course id_schedule name color
           SCHEDULE id_schedule id_class time_start time_end day
                <th>id Clase</th>
                <th>Curso</th>
                <th>Descrip C</th>
                <th>Inicio C</th>
                <th>Fin C</th>
                <th>Activo</th>
                <th>Clase</th>
                <th>Color Cl</th>
                <th>Hora Cl</th>
                <th>Hora Fin Cl</th>
                <th>Día Cl</th>
        */
        $ordering = [
            'c.name' => 'Curso',
            'description' => 'Descrip C',
            'start_date' => 'Inicio C',
            'end_date' => 'Fin C',
            'active' => 'Activo',
            /*'id_schedule' => 'id_schedule',*/
            'cl.name' => 'Clase',
            'color' => 'Color Cl',
            'time_start' => 'Hora Cl',
            'time_end' => 'Hora fin Cl',
            'day' => 'Día Cl'
        ];
        return $ordering;
    }
}
?>
