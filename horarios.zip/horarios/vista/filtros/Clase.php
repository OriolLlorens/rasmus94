<?php
class Clase
{
    /**
     *
     */
    public function __construct()
    {
    }

    /**
     *
     */
    public function __destruct()
    {
    }
    
    /**
     * Set friendly columns\' names to order tables\' entries
     */
    public function setOrderingValues()
    {
        $ordering = [
            'id_class' => 'id_clase',
            'id_teacher' => 'id_profesor',
            'id_course' => 'id_Curso',
            'id_schedule' => 'id_schedule',
            'name' => 'Nombre',
            'color' => 'Color'
        ];
        return $ordering;
    }
}
?>
