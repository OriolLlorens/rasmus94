<?php
class Enrollment
{
    /**
     *
     */
    public function __construct()
    {
    }

    /**
     *
     */
    public function __destruct()
    {
    }
    
    /**
     * Set friendly columns\' names to order tables\' entries
     */
    public function setOrderingValues()
    {
        $ordering = [
            'id_enrollment' => 'Matrícula',
            'id_student' => 'Estudiante matriculado',
            'id_course' => 'Curso',
            'status'=> 'Estado'
        ];

        return $ordering;
    }
    public function removeStudentOrderingValue()
    {
        $ordering = [
            'id_enrollment' => 'Matrícula',
            'id_course' => 'Curso',
            'status'=> 'Estado'
        ];

        return $ordering;
    }
}
?>
