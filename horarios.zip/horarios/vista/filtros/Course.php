<?php
class Course
{
    /**
     *
     */
    public function __construct()
    {
    }

    /**
     *
     */
    public function __destruct()
    {
    }
    
    /**
     * Set friendly columns\' names to order tables\' entries
     */
    public function setOrderingValues()
    {
        $ordering = [
            'id_course' => 'id',
            'name' => 'Nombre',
            'description' => 'Descripción',
            'date_start' => 'Fecha inicio',
            'date_end' => 'Fecha Fin',
            'active' => 'Activo'
        ];
        return $ordering;
    }
}
?>
