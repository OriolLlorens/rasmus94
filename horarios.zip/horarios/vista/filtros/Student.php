<?php
class Student
{
    /**
     *
     */
    public function __construct()
    {
    }

    /**
     *
     */
    public function __destruct()
    {
    }
    
    /**
     * Set friendly columns\' names to order tables\' entries
     */
    public function setOrderingValues()
    {
        $ordering = [
            'id' => 'Código',
            'username' => 'Usuario',
            'pass' => 'Password',
            'email' => 'Usuario',
            'name' => 'Nombre',
            'apellidos' => 'Apellidos',
            'telephone' => 'Teléfono',
            'nif' => 'Apellidos',
            'date_registered' => 'Registrado'
    ];
        return $ordering;
    }
}
?>
