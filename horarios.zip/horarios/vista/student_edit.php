<?php
session_start();
require_once '../config/config.php';
require_once BASE_PATH .'/includes/auth_validate.php';


// Sanitize if you want
if (isset($_SESSION['id_student'])) {
    $codigo=$_SESSION['id_student'];
} else {
    // si es administrador el que edita lo envía aquí por GET
    $codigo = filter_input(INPUT_GET, 'codigo',FILTER_SANITIZE_STRING); // FILTER_VALIDATE_INT);
}
$operation = filter_input(INPUT_GET, 'operation',FILTER_SANITIZE_STRING); 
($operation == 'edit') ? $edit = true : $edit = false;

$db = getDbInstance();

//Handle update request. As the form's action attribute is set to the same script, but 'POST' method,

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //Get id form query string parameter.
    /*if (isset($_SESSION['id_student'])) {
        $codigo=$_SESSION['id_student'];
    } else {
        $codigo = filter_input(INPUT_GET, 'codigo', FILTER_SANITIZE_STRING);
    }*/

    // Obtener datos de entrada data
    $data_to_update = filter_input_array(INPUT_POST);
    //    U P D A T E

    $db->where('id',$codigo);
    $stat = $db->update('students', $data_to_update);

    if($stat) {
        $_SESSION['success'] = "Estudiante actualizado!";
        // Redirect NO ADMIN
        if (isset($_SESSION['id_student'])) {
            header('location: index.php');
        // Redirect ADMIN
        } else {
            header('location: students.php');
        }
        //Important! Don't execute the rest put the exit/die. 
        exit();
    }
}

$student=NULL;

// If edit variable is set, we are performing the update operation.
if ($edit) {
    $db->where('id', $codigo);
    //Get data to pre-populate the form.
    $student = $db->getOne("students");
}
?>


<?php
require_once BASE_PATH .'/includes/header_courses.php';
?>
<div id="page-wrapper">
    <div class="row">
        <h2 class="page-header">Actualizar estudiante</h2>
    </div>
    <!-- Flash messages -->
    <?php
    include('../includes/flash_messages.php')
    ?>

    <form class="" action="" method="post" enctype="multipart/form-data" id="contact_form">
        
        <?php
            //Include the common form for add and edit  
            require_once('../forms/student_form.php');
        ?>
    </form>
</div>

<?php require_once BASE_PATH . '/includes/footer.php'; ?>