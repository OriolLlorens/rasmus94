<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_validate.php';


// Sanitize if you want
$codigo = filter_input(INPUT_GET, 'id_class', FILTER_VALIDATE_INT);
$operation = filter_input(INPUT_GET, 'operation',FILTER_SANITIZE_STRING); 
($operation == 'edit') ? $edit = true : $edit = false;

$title="Actualizar clase";
$db = getDbInstance();

//Handle update request. As the form's action attribute is set to the same script, but 'POST' method,

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    //Get customer id form query string parameter.
    $codigo = filter_input(INPUT_GET, 'id_class', FILTER_SANITIZE_STRING);

    // Datos de entrada
    $data_to_update = filter_input_array(INPUT_POST);

    //$data_to_update['fecha'] = date('Y-m-d H:i:s');
    $db = getDbInstance();

    if ($edit) {
    $db->where('id_class', $codigo);
    $stat = $db->update('class', $data_to_update);

    if ($stat) {
        $_SESSION['success'] = "Clase actualizada!";
        //Redirect to the listing page,
        header('location: classes.php');
        //Important! Don't execute the rest put the exit/die. 
        exit();
    }

    } else  {
        //Insert timestamp
        //$data_to_store['created_at'] = date('Y-m-d H:i:s');

        //Mass Insert Data. Keep "name" attribute in html form same as column name in mysql table.
        $data_to_store = array_filter($_POST);

        $last_id = $db->insert('class', $data_to_store);
        if($last_id) {
            $_SESSION['success'] = "Clase añadida!";
            header('location: classes.php');
            exit();
        }
        else {
            echo 'fallo al insertar clase: ' . $db->getLastError();
            exit();
        }
    }
}

//If edit variable is set, we are performing the update operation.
if($edit) {
    $title="Actualizar clase";
    $db->where('id_class', $codigo);

    // Get data to pre-populate the form.
    $class = $db->getOne("class");
    $rowProfesores=$db->get("teachers");
    $rowCursos=$db->get("courses");
    $rowSchedules=$db->get("schedule");

} else { // suppuestamente es create

    $title="Crear nueva clase";
    // Get data to pre-populate the form.
    $rowProfesores=$db->get("teachers");
    $rowCursos=$db->get("courses");
    $rowSchedules=$db->get("schedule");

}
?>


<?php
    include_once '../includes/header_courses.php';
?>
<div id="page-wrapper">
    <div class="row">
        <h2 class="page-header"><?php echo $title; ?></h2>
    </div>
    <!-- Flash messages -->
    <?php
    include('../includes/flash_messages.php')
    ?>

    <form class="" action="" method="post" enctype="multipart/form-data" id="contact_form">
        <?php
            //Include the common form for add and edit  
            require_once('../forms/class_form.php');
        ?>
    </form>
</div>

<?php include_once '../includes/footer.php'; ?>