<?php
session_start();
require_once '../config/config.php';
require_once BASE_PATH . '/includes/auth_validate.php';

//Get DB instance. function is defined in config.php
$db = getDbInstance();
//Get Dashboard information
if (isset($_SESSION['id_student'])){
    $id=intval($_SESSION['id_student']);
}
$title="Usuario estudiante";
// E S T O   Y A   F U N C I O N A
if ($_SESSION['esAdmin'] == 1) {
    $title="Modo administrador";
    $numEstudiantes= $db->getValue ("students", "count(*)");
    $numCourses = $db->getValue ("courses", "count(*)");
    $numEnrollment = $db->getValue ("enrollment", "count(*)");
    $numClases = $db->getValue ("class", "count(*)");
} else {
    // courses no lleva la clave id_student por eso no filtra
    $numCourses = sizeof(DAOCourses::obtenerMatriculasPorEstudiante($_SESSION['id_student']));
    $numEvents = sizeof(DAOCourses::obtenerCalendario());

    $db->where("id_student", $id);
    $numEnrollment = $db->getValue ("enrollment", "count(*)");

    $numClases = sizeof(DAOCourses::obtenerHorariosClasesPorEstudiante('id_student',$_SESSION['id_student'],null,null));
}

//$db->getValue ("courses", "count(*)");

include_once('../includes/header_courses.php');
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header"><?php echo $title ?> </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <?php if ($_SESSION['esAdmin'] == 1) {?>
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-user fa-5x"></i>
                            </div>
                            <div class="col-xs-9 text-right">
                                <div class="huge"><?php echo $numEstudiantes;?></div><div>Estudiantes</div>
                            </div>
                        </div>
                    </div>
                    <a href="students.php">
                        <div class="panel-footer">
                            <span class="pull-left">Gestionar estudiantes</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
        </div>
        <?php } ?>

            <!--calendario-->
            <?php if ($_SESSION['esAdmin'] != 1) { ?>
            <div class="col-lg-3 col-md-6">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-calendar fa-5x"></i>
                            </div>
                            <div class="col-xs-9 text-right">
                                <!--<div class="huge"><?php /*echo $numProductos;*/?></div>-->
                                <div class="huge"><?php echo $numEvents;?></div>
                                <div>Entradas</div>
                            </div>
                        </div>
                    </div>
                    <a href="calendar.php">
                        <div class="panel-footer">
                            <!--<span class="pull-left">Ver productos</span>-->
                            <span class="pull-left">Ver entradas</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
            <?php } ?>
        <!--cursos-->
        <div class="col-lg-3 col-md-6">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-book fa-5x"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <!--<div class="huge"><?php /*echo $numProductos;*/?></div>-->
                            <div class="huge"><?php echo $numCourses;?></div>
                            <div>Cursos</div>
                        </div>
                    </div>
                </div>
                <a href="courses.php">
                    <div class="panel-footer">
                        <!--<span class="pull-left">Ver productos</span>-->
                        <span class="pull-left">Ver Cursos</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
        <!--matriculas-->
        <div class="col-lg-3 col-md-6">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-object-group fa-5x"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <!--<div class="huge"><?php /*echo $numenrollment; */?></div>-->
                            <div class="huge"><?php echo $numEnrollment; ?></div>
                            <div>Matrículas</div>
                        </div>
                    </div>
                </div>
                <a href="enrollments.php">
                    <div class="panel-footer">
                        <!--<span class="pull-left">View Details</span>-->
                        <span class="pull-left">Ver Matrículas</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>

        <?php if ($_SESSION['esAdmin'] == 1) {?>
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-user fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo $numClases;?></div><div>Clases totales</div>
                                </div>
                            </div>
                        </div>
                        <a href="classes.php">
                            <div class="panel-footer">
                                <span class="pull-left">Gestionar clases</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
        <?php } ?>

        <div class="col-lg-3 col-md-6">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col-xs-3">
                            <i class="fa fa-tasks fa-5x"></i>
                        </div>
                        <div class="col-xs-9 text-right">
                            <!--<div class="huge"><?php /*echo $numenrollment; */?></div>-->
                            <div class="huge"><?php echo $numClases; ?></div>
                            <div>Horarios</div>
                        </div>
                    </div>
                </div>
                <a href="horarios_clases.php">
                    <div class="panel-footer">

                        <span class="pull-left">Ver Horarios de clases</span>
                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                        <div class="clearfix"></div>
                    </div>
                </a>
            </div>
        </div>
    </div>
    <!-- /.row -->
    <div class="row">
        <div class="col-lg-8">


            <!-- /.panel -->
        </div>
        <!-- /.col-lg-8 -->
        <div class="col-lg-4">

            <!-- /.panel .chat-panel -->
        </div>
        <!-- /.col-lg-4 -->
    </div>
    <!-- /.row -->
</div>
<!-- /#page-wrapper -->

<?php require_once BASE_PATH . '/includes/footer.php'; ?>
