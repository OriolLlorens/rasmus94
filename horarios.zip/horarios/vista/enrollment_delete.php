<?php 
session_start();
require_once '../config/config.php';
require_once '../includes/auth_validate.php';
$codigo = filter_input(INPUT_POST, 'del_id');

// recibe el parámetro $codigo a borrar
if ($codigo && $_SERVER['REQUEST_METHOD'] == 'POST') {

    if($_SESSION['esAdmin']!=1) {
		$_SESSION['failure'] = "No se tienes permisos para esta acción.";
    	header('location: enrollments.php');
        exit;
	}


    $db = getDbInstance();
    $db->where('id_enrollment', $codigo);
    $status = $db->delete('enrollment');

    $_SESSION['info'] =$status ? "Matrícula borrada de la BD!" : "Error al borrar matrícula";

    header('location: enrollments.php');
    exit;
    
}