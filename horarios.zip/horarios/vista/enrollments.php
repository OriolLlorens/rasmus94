<?php
session_start();
require_once '../config/config.php';
require_once BASE_PATH . '/includes/auth_validate.php';

// model class
require_once BASE_PATH . '/vista/filtros/Enrollment.php';

$db=getDBInstance();

/*if ($_SESSION['esAdmin'] == 1) {
} else {
    $db->where("id_student", $_SESSION['id_student']);
}
$rows=$db->get('enrollment');*/

// r o w s
$table="enrollment";
$codigo="id_enrollment";
$enrollment = new Enrollment();
    $search_string = filter_input(INPUT_GET, 'search_string');
    $filter_col = filter_input(INPUT_GET, 'filter_col');
    if (!$filter_col) {
        $filter_col = $codigo;
        $search_string = null;
    }

    if ($_SESSION['esAdmin'] == 1) {
        $rows=DAOCourses::itemsPorFiltroYWhere($table,null,null,$filter_col,$search_string);
    } else {
        $rows=DAOCourses::itemsPorFiltroYWhere($table,'id_student',$_SESSION['id_student'],$filter_col,$search_string);
        //$db->where("id_student", $_SESSION['id_student']);
    }

//$rows=$db->get('enrollment');

/*$allowed  = [$search_string];
$filtered = array_filter(
    $rows,
    function ($filter_col) use ($allowed) {
        return in_array($filter_col, $allowed);
    },
    ARRAY_FILTER_USE_KEY
);
$rows=$filtered;*/
    /*$my_array = ['foo' => 1, 'hello' => 'world'];
$allowed  = ['foo', 'bar'];
$filtered = array_filter(
    $my_array,
    function ($key) use ($allowed) {
        return in_array($key, $allowed);
    },
    ARRAY_FILTER_USE_KEY
);*/

//$rows = DAOCourses::obtenerItemsPorFiltro("enrollment", $filter_col, $search_string);


/*}
else {
// Get Input data from query string
    $search_string = filter_input(INPUT_GET, 'search_string');
    $filter_col = filter_input(INPUT_GET, 'filter_col');

// Si no hay filtro haré un select de todos los registros

    if (!$filter_col) {
        $filter_col = 'id_enrollment';
        $search_string = null;
    }
    $rows = DAOCourses::obtenerItemsPorFiltro("enrollment", $filter_col, $search_string);
}*/

/*// Per page limit for pagination.
$pagelimit = 15;
// Get current page.
$page = filter_input(INPUT_GET, 'page');
if (!$page) {	$page = 1;}
// Primer campo de ordenación en caso de no filtrar
if (!$filter_col) { $filter_col = 'codigo'; }
if (!$order_by) { $order_by = 'Desc';}
//Get DB instance. i.e instance of MYSQLiDB Library
$db = getDbInstance();
$select = array('codigo', 'persona', 'fecha', 'importe', 'estado');
if ($search_string) {
	$db->where('persona', '%' . $search_string . '%', 'like');
	$db->orwhere('fecha', '%' . $search_string . '%', 'like');
    $db->orwhere('estado', '%' . $search_string . '%', 'like');
}
//If order by option selected
if ($order_by) { $db->orderBy($filter_col, $order_by); }
// Set pagination limit
$db->pageLimit = $pagelimit;
// enrollment array.
$rows = $db->arraybuilder()->paginate('enrollment', $page, $select);
$total_pages = $db->totalPages;
*/


// P E N D I E N T E    initialize a new array
/*$enrollmentDetalle=array();
foreach ($rows as $p) {
    $detalle=DAOCourses::obtenerCursosPorEnrollment($p["id_enrollment"]);
    $enrollmentDetalle[$p["id_enrollment"]] =$detalle;
}*/

    // loop through array de enrollment y añade and add su detalle como nuevo array
    //$db = getDbInstance();
    //$selectDetalle = array('codigo_pedido', 'codigo_producto', 'precio_unitario', 'unidades');
    //$db->where('codigo_pedido', stripslashes($p["codigo"]));
    //$detalle = $db->arraybuilder()->paginate('detalle',0, $selectDetalle);

    /*array("codigo_pedido"    => $p["codigo_pedido"], "codigo_producto"  => $p["codigo_producto"],"precio_unitario"  => $p["precio_unitario"],   "unidades" => $p["unidades"] );*/


// output new array
//echo"<pre>".print_r($enrollmentDetalle,true)."</pre>";
//$rowsDetalle=array[$rows];

include BASE_PATH . '/includes/header_courses.php';
?>
<!-- Main container -->
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-6">
            <h1 class="page-header">Matrículas</h1>
        </div>
        <div class="col-lg-6">
            <div class="page-action-links text-right">
                <a href="enrollment_add_edit.php?operation=create" class="btn btn-success"><i class="glyphicon glyphicon-plus"></i> Añadir</a>
            </div>
        </div>
    </div>
    <?php include BASE_PATH . '/includes/flash_messages.php';?>

    <!-- Filters -->
    <div class="well text-center filter-form">
        <form class="form form-inline" method="get" action="">
            <label for="input_search">Buscar</label>
            <input type="text" class="form-control" id="input_search" name="search_string" value="<?php echo xss_clean($search_string); ?>">
            <label for="input_order">Por</label>
            <select name="filter_col" class="form-control">
                <?php
                /*echo ' <option value="" ' . '>' . '""</option>';*/
                $currOrdering=($_SESSION['esAdmin']==1)? $enrollment->setOrderingValues(): $enrollment->removeStudentOrderingValue();

            foreach ($currOrdering as $opt_value => $opt_name):
	        ($filter_col === $opt_value) ? $selected = 'selected' : $selected = '';
	        echo ' <option value="' . $opt_value . '" ' . $selected . '>' . $opt_name . '</option>';
            endforeach;
            ?>
            </select>
            <input type="submit" value="Filtrar" class="btn btn-primary">
        </form>
    </div>
    <hr>
    <!-- //Filters -->
    <!--<div id="export-section">
        <a href="lala-enrollment_export.php"><button class="btn btn-sm btn-primary">Export to CSV <i class="glyphicon glyphicon-export"></i></button></a>
    </div>-->

    <!-- Table -->
    <table class="table table-striped table-bordered table-condensed">
        <thead>
            <tr>
                <th>Matrícula</th>
                <?php if ($_SESSION['esAdmin'] == 1) { ?><th>Estudiante</th> <?php } ?>
                <!--<th>Estudiante</th>-->

                <th>Curso</th>
                <th>Estado</th>

                <?php if ($_SESSION['esAdmin'] == 1) { ?><th>Acciones</th> <?php } ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $row): ?>
            <tr>
                <td aria-disabled="true"><?php echo $row[$codigo]; ?></td>
                <?php if ($_SESSION['esAdmin'] == 1) { ?>
                    <td aria-disabled="true"><?php echo xss_clean($row['id_student']); ?></td>
                <?php } ?>
                <td><?php echo xss_clean($row['id_course']); ?></td>
                <td><?php echo xss_clean($row['status']); ?></td>

                <?php if ($_SESSION['esAdmin'] == 1) { ?>
                <td>
                    <?php /*if($row['status']==1) { */?><!--
                    <a href="enrollment_add_edit.php?id_enrollment=<?php /*echo $row[$codigo]; */?>&operation=edit" class="btn btn-primary disabled"><i class="glyphicon glyphicon-edit"></i></a>
                    --><?php /*} else { */?>
                        <a href="enrollment_add_edit.php?id_enrollment=<?php echo $row[$codigo]; ?>&operation=edit" class="btn btn-primary"><i class="glyphicon glyphicon-edit"></i></a>
                    <?php /*}   */?>
                    <a href="#" class="btn btn-danger delete_btn" data-toggle="modal" data-target="#confirm-delete-<?php echo $row['id_enrollment']; ?>"><i class="glyphicon glyphicon-trash"></i></a>
                    <!--<a data-toggle="collapse" href="#collapse<?php /*echo $row[$codigo];*/?>">Detalles</a>-->
                </td>
                <?php } ?>
            </tr>
            <!--<tr>
               <td colspan="5">
                   <div id="collapse<?php /*echo $row['id_enrollment'];*/?>" class="panel-collapse collapse">
                   <table class="table table-striped table-bordered table-condensed">
                    <thead>
                    <tr>
                        <th>Matricula</th>
                        <th>Curso</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Inicio</th>
                        <th>Fin</th>
                        <th>Activo</th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php /*foreach ($enrollmentDetalle[$row['codigo']] as $detalle): */?>
                        <tr>
                            <td><?php /*echo xss_clean($detalle['id_enrollment']); */?></td>
                            <td><?php /*echo xss_clean($detalle['id_course']); */?></td>
                            <td><?php /*echo xss_clean($detalle['name']); */?></td>
                            <td><?php /*echo xss_clean($detalle['description']); */?></td>
                            <td><?php /*echo xss_clean($detalle['datee_start']); */?></td>
                            <td><?php /*echo xss_clean($detalle['date_end']); */?></td>
                            <td><?php /*echo xss_clean($detalle['active']); */?></td>
                        </tr>
                    <?php /*endforeach;*/?>
                    </tbody>
                </table>
                   </div>
               </td>
            </tr>-->

            <?php if ($_SESSION['esAdmin'] == 1) { ?>
            <!-- Delete Confirmation Modal -->
            <div class="modal fade" id="confirm-delete-<?php echo $row[$codigo]; ?>" role="dialog">
                <div class="modal-dialog">
                    <form action="enrollment_delete.php" method="POST">
                        <!-- Modal content -->
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">Confirmar</h4>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="del_id" id="del_id" value="<?php echo $row['id_enrollment']; ?>">
                                <p>Desea borrar la matrícula?</p>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-default pull-left">Sí</button>
                                <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <?php } ?>
            <!-- //Delete Confirmation Modal -->
            <?php endforeach;?>
        </tbody>
    </table>
    <!-- //Table -->
</div>
<!-- //Main container -->
<?php include BASE_PATH . '/includes/footer.php';?>