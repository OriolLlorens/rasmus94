<?php
require_once '../config/config.php';
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $table="students";
    $campoPass='pass';
    if (isset($_POST['admin'])) {
        if ($_POST['admin']=="esAdmin") {
            //$_SESSION['esAdmin'] = 1;
            $table="users_admin";
            $campoPass='password';
            //echo $_POST['admin']; // Displays value of checked checkbox.
        }
    }

    /*$usuario = filter_input(INPUT_POST, 'usuario');*/
    $username = filter_input(INPUT_POST, 'username');
	$pass = filter_input(INPUT_POST, 'pass');

	$db = getDbInstance(); //Get DB instance.
    $db->where("username", $username);
	$row = $db->get($table);

	if ($db->count >= 1) {
        /*$db_admin = $row[0]['admin'];*//*$db_password = $row[0]['clave'];*/
        $db_password = $row[0][$campoPass];		/*$codigo = $row[0]['codigo'];*/
        if ($pass == $db_password)  {
            if ($table == 'students') {
                $_SESSION['id_student'] = $row[0]['id'];
                $_SESSION['user_logged_in'] = TRUE;
                $_SESSION['esAdmin'] = 0;
            } else{
                //$_SESSION['id_student'] = ''; //$row[0]['id'];
                $_SESSION['user_logged_in'] = TRUE;
                $_SESSION['esAdmin'] = 1;
            }
			/*  En los casos que no se pueda dar de alta o acceder,
			 * -mostrar los mensajes de error correspondientes.
			 * Si no es un usuario administrador, seleccionar qué cursos o ciclos está inscrito*/
            header('Location:index.php');exit;
		}
        else {
            $_SESSION['login_failure'] = "Clave no válida";
            header('Location:login.php');
            exit;
        }
	} else {

		$_SESSION['login_failure'] = "No existe este usuario";
		header('Location:login.php');
		exit;
	}

}
else {
	die('No permitido');
}