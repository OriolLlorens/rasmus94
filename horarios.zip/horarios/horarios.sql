-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 29-11-2022 a las 10:49:06
-- Versión del servidor: 10.1.37-MariaDB
-- Versión de PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `horarios`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `class`
--

CREATE TABLE `class` (
  `id_class` int(11) NOT NULL,
  `id_teacher` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `id_schedule` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `color` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `class`
--

INSERT INTO `class` (`id_class`, `id_teacher`, `id_course`, `id_schedule`, `name`, `color`) VALUES
(1, 1, 1, 1, 'info', 'red'),
(2, 1, 2, 2, 'mates', 'yellow'),
(3, 4, 4, 2, 'fisi', 'orange'),
(4, 2, 3, 5, 'Altillo', 'purple');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `courses`
--

CREATE TABLE `courses` (
  `id_course` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `description` varchar(500) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_spanish_ci ROW_FORMAT=COMPACT;

--
-- Volcado de datos para la tabla `courses`
--

INSERT INTO `courses` (`id_course`, `name`, `description`, `date_start`, `date_end`, `active`) VALUES
(1, 'Autocad', 'diseño asistido', '2022-11-26', '2022-12-20', 1),
(2, 'Autocad', 'diseño asistido', '2022-12-26', '2022-12-23', 1),
(3, 'Pov-Ray', 'diseño artístico', '2023-08-26', '2023-10-20', 1),
(4, 'Química', 'Aromáticos', '2022-11-30', '2023-02-03', 1),
(5, 'INE', 'Estadística', '2022-11-30', '2022-12-11', 1),
(6, 'Idiomas', 'Latín y Griego.', '2023-01-04', '2023-01-27', 1),
(12, 'eeeee', 'eeewew', '2022-11-10', '2022-11-08', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `enrollment`
--

CREATE TABLE `enrollment` (
  `id_enrollment` int(11) NOT NULL,
  `id_student` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `enrollment`
--

INSERT INTO `enrollment` (`id_enrollment`, `id_student`, `id_course`, `status`) VALUES
(1, 1, 1, 1),
(2, 1, 5, 1),
(3, 6, 2, 1),
(4, 1, 3, 1),
(5, 24, 1, 1),
(6, 35, 4, 1),
(7, 36, 1, 1),
(8, 42, 2, 1),
(9, 35, 3, 1),
(10, 42, 4, 1),
(13, 0, 3, 0),
(16, 0, 2, 0),
(20, 1, 2, 1),
(21, 1, 4, 1),
(24, 47, 3, 0),
(28, 36, 2, 1),
(29, 43, 4, 1),
(31, 1, 6, 1),
(32, 1, 12, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `schedule`
--

CREATE TABLE `schedule` (
  `id_schedule` int(11) NOT NULL,
  `id_class` int(11) NOT NULL,
  `time_start` time NOT NULL,
  `time_end` time NOT NULL,
  `day` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `schedule`
--

INSERT INTO `schedule` (`id_schedule`, `id_class`, `time_start`, `time_end`, `day`) VALUES
(1, 1, '53:00:00', '55:00:00', '2022-11-24'),
(2, 1, '15:00:00', '17:00:00', '2022-11-27'),
(4, 4, '05:00:00', '06:00:00', '2022-11-20'),
(5, 3, '05:00:00', '06:00:00', '2022-11-20'),
(6, 2, '20:00:00', '21:00:00', '2022-11-30'),
(7, 1, '20:00:00', '21:00:00', '2022-11-30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `telephone` varchar(50) NOT NULL,
  `nif` varchar(50) NOT NULL,
  `date_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Volcado de datos para la tabla `students`
--

INSERT INTO `students` (`id`, `username`, `pass`, `email`, `name`, `surname`, `telephone`, `nif`, `date_registered`) VALUES
(1, 'juan', '1234', 'juan@gmail.com', 'juanito', 'romero', '934567896', '44521624H', '2022-11-21 07:25:39'),
(6, 'Edua', '1234', 'edu@gmail.com', 'Edu', 'Dorado', '55555', '55', '0000-00-00 00:00:00'),
(24, 'kiwi', '4567', 'kiwito@telefonica.net', 'kiwi', 'Lust', '936215478', '45789999Y', '0000-00-00 00:00:00'),
(35, 'cris', '1234', 'cris@gmail.com', 'cris', 'fffff', '44555555', 'sdfsf4444', '0000-00-00 00:00:00'),
(36, 'cuca', '1234', 'cuca@gmx.con', 'cuca', 'rella', '445599332', '4478955T', '0000-00-00 00:00:00'),
(42, 'clara', '1234', 'clara@gmail.com', 'clara', 'rrrr', '9999556565', 'dfsrgeger5', '0000-00-00 00:00:00'),
(43, 'juani', '1234', 'ffff@gmail.com', 'juan', 'betanzos', '635124568', 'dddddddd2', '2022-11-21 11:36:33'),
(45, 'k', 'kkkkk', 'k@ggg.es', 'k', 'kkkk', '8888888', 'kjyhjgyjyuuj', '2022-11-22 08:01:31'),
(47, 'eeee', 'eeee', 'eeee@ee.es', 'eeee', 'eee', '933445678', '', '2022-11-22 08:16:47'),
(48, '2222', '2222', 'wwww@google.es', 'fffff', 'fff', 'fffff', 'fffff', '2022-11-22 19:47:33'),
(49, 'jacobo', 'jacobo', 'jacobo@gmx.net', 'jac', 'planells', '442565874', '34567890X2', '2022-11-22 19:59:10'),
(50, 'oooo', '1234', 'oooo@gmailnet', 'oooo', 'rrrr', '', '', '2022-11-24 11:27:34'),
(51, 'llkhjkhjkhj', 'kjkghjkgjh', 'kghkghkj@gggg.es', 'fgfgbfgdfg', 'dfgserfgdsfggf', 'sdfg', '', '2022-11-24 13:41:48'),
(52, 'dsqwddqsad', 'qdsqwdwq', 'eeee@ee.es', 'sadASDa', 'sSas', '', '', '2022-11-24 13:45:49'),
(53, 'reqwrqr', 'rq', 'rqr@fff.es', 'affqewf', 'fwf', '', '', '2022-11-24 13:47:44'),
(54, 'fqefqwefw', 'fqwfqwf', 'rqr@fff.es', 'fqwef', 'qwe', '', '', '2022-11-24 13:48:07');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `teachers`
--

CREATE TABLE `teachers` (
  `id_teacher` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `telephone` varchar(50) NOT NULL,
  `nif` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `teachers`
--

INSERT INTO `teachers` (`id_teacher`, `name`, `surname`, `telephone`, `nif`, `email`) VALUES
(1, 'oscar', 'garcía', '655444444', '44444444r', 'oscar@tote.es'),
(2, 'demetrio', 'vega', '6554444', '44444442r', 'demetrio@hotmail.es'),
(3, 'berta', 'llul', '6552509', '1233455J', 'oscar@tote.es'),
(4, 'oscar', 'marí', '3456722', '44772333L', 'oscar@tote.es');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users_admin`
--

CREATE TABLE `users_admin` (
  `id_user_admin` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `users_admin`
--

INSERT INTO `users_admin` (`id_user_admin`, `username`, `name`, `email`, `password`) VALUES
(1, 'admin', 'admin', 'admin@google.es', '1234'),
(12, 'admin0', 'admin0', 'admin0@google.es', '1234'),
(32, 'luna', 'luna', 'luna@protonmail.com', '1234');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id_class`),
  ADD UNIQUE KEY `id_teacher` (`id_teacher`,`id_course`,`id_schedule`);

--
-- Indices de la tabla `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id_course`),
  ADD UNIQUE KEY `name` (`name`,`date_start`,`date_end`);

--
-- Indices de la tabla `enrollment`
--
ALTER TABLE `enrollment`
  ADD PRIMARY KEY (`id_enrollment`),
  ADD UNIQUE KEY `id_student` (`id_student`,`id_course`);

--
-- Indices de la tabla `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`id_schedule`);

--
-- Indices de la tabla `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`email`);

--
-- Indices de la tabla `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id_teacher`);

--
-- Indices de la tabla `users_admin`
--
ALTER TABLE `users_admin`
  ADD PRIMARY KEY (`id_user_admin`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `class`
--
ALTER TABLE `class`
  MODIFY `id_class` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `courses`
--
ALTER TABLE `courses`
  MODIFY `id_course` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `enrollment`
--
ALTER TABLE `enrollment`
  MODIFY `id_enrollment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de la tabla `schedule`
--
ALTER TABLE `schedule`
  MODIFY `id_schedule` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT de la tabla `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id_teacher` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `users_admin`
--
ALTER TABLE `users_admin`
  MODIFY `id_user_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `class`
--
ALTER TABLE `class`
  ADD CONSTRAINT `class_ibfk_1` FOREIGN KEY (`id_teacher`) REFERENCES `teachers` (`id_teacher`);

--
-- Filtros para la tabla `users_admin`
--
ALTER TABLE `users_admin`
  ADD CONSTRAINT `users_admin_ibfk_1` FOREIGN KEY (`id_user_admin`) REFERENCES `usuarios` (`codigo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
