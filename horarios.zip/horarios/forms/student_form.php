<fieldset>
    <!--<div class="form-group">
        <label>Admin * </label>
        <label class="radio-inline">
            <input type="radio" name="admin" value="1" <?php /*echo ($edit && $students['admin'] ==1) ? "checked": "" ; */?> required="required"/> Es Admin
        </label>
        <label class="radio-inline">
            <input type="radio" name="admin" value="0" <?php /*echo ($edit && $students['admin'] ==0)? "checked": "" ; */?> required="required" id="noAdmin"/> No Admin
        </label>
    </div>-->

    <div class="form-group">
        <label for="nombre">Usuario *</label>
          <input type="text" name="username" value="<?php echo htmlspecialchars($edit ? $student['username'] : '', ENT_QUOTES, 'UTF-8'); ?>"
                 placeholder="usuario" class="form-control" required="required" id = "username" >
    </div> 

    <div class="form-group">
        <label for="pass">Password *</label>
        <input type="password" name="pass" value="<?php echo htmlspecialchars($edit ? $student['pass'] : '', ENT_QUOTES, 'UTF-8'); ?>"
               placeholder="password" class="form-control" required id="pass">
    </div>
    <div class="form-group">
        <label for="email">Email *</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($edit ? $student['email'] : '', ENT_QUOTES, 'UTF-8'); ?>"
               placeholder="email" class="form-control" required id="email">
    </div>
    <div class="form-group">
        <label for="nombre">Nombre</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($edit ? $student['name'] : '', ENT_QUOTES, 'UTF-8'); ?>"
               placeholder="Nombre" class="form-control" required="required" id = "nombre" >
    </div>
    <div class="form-group">
        <label for="nombre">Apellidos</label>
        <input type="text" name="surname" value="<?php echo htmlspecialchars($edit ? $student['surname'] : '', ENT_QUOTES, 'UTF-8'); ?>"
               placeholder="apellidos" class="form-control" required="required" id = "apellidos" >
    </div>
    <div class="form-group">
        <label for="telefono">Teléfono</label>
        <input  type="text" name="telephone"
                value="<?php echo htmlspecialchars($edit ? $student['telephone'] : '', ENT_QUOTES, 'UTF-8'); ?>"
                placeholder="933641228" class="form-control" id="telefono">
    </div>
    <div class="form-group">
        <label for="nif">NIF</label>
        <input  type="text" name="nif"
                value="<?php echo htmlspecialchars(($edit) ? $student['nif'] : '', ENT_QUOTES, 'UTF-8'); ?>"
                placeholder="XXXXXXXXA" class="form-control" id="nif">
    </div>
    <!--<div class="form-group">
        <label>Fecha</label>
        <input type="datetime-local"  name="date_registered" value="<?php /*echo htmlspecialchars($edit ? $students['date_registered'] : new (\DateTime())->format('Y-m-d H:i:s'), ENT_QUOTES, 'UTF-8'); */?>"
               placeholder="fecha" class="form-control"  type="date" id="date_registered">
    </div>-->
    
    <!--<div class="form-group">
        <label>Población </label>
           <?php /*$opt_arr = array("Valencia", "Cuenca", "Castellón", "Alicante", "Albacete", "Teruel"); */?>
            <select name="poblacion" class="form-control selectpicker" required>
                <option value=" " >Seleccione población</option>
                <?php
/*                foreach ($opt_arr as $opt) {
                    if ($edit && $opt == $students['poblacion']) {
                        $sel = "selected";
                    } else {
                        $sel = "";
                    }
                    echo '<option value="'.$opt.'"' . $sel . '>' . $opt . '</option>';
                }
                */?>
            </select>
    </div>  -->


    <!--<div class="form-group">
        <label>Date of birth</label>
        <input name="date_of_birth" value="<?php /*echo htmlspecialchars($edit ? $usuario['date_of_birth'] : '', ENT_QUOTES, 'UTF-8'); */?>"  placeholder="Birth date" class="form-control"  type="date">
    </div>
-->
    <div class="form-group text-center">
        <label></label>
        <button type="submit" class="btn btn-warning" >Guardar <span class="glyphicon glyphicon-send"></span></button>
    </div>            
</fieldset>
