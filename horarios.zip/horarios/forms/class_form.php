<fieldset>

    <div class="form-group">
        <label for="codigo">id clase *</label>
        <input type="text" name="codigo" value="<?php echo htmlspecialchars($edit ? $class['id_class'] : '', ENT_QUOTES, 'UTF-8'); ?>"
               placeholder="" class="form-control" disabled id = "id_class" >
    </div>



    <div class="form-group">
    <label for="profesor">Profesor (debe existir en BD, su código) *</label>
    <select name="id_teacher" class="form-control">
        <?php foreach( $rowProfesores as $var => $profesor ): ?>
            <option name="<?php echo $profesor['id_teacher'] ?>"
            value="<?php echo $profesor['id_teacher'] ?>"
                <?php
                if ($edit) {
                if( $class['id_teacher'] == $profesor['id_teacher'] ) : ?> selected="selected" <?php endif; ?>
                  <?php } ?>
            >
                <?php echo $profesor['id_teacher'].' '. $profesor['name'].' '. $profesor['surname'] ?>
            </option>
        <?php endforeach; ?>
    </select>
    </div>
    <!--
    <form action="" method="post">
        <select name="Movies">
            <option value="" disabled selected>Select option</option>
            <option value="seven_samurai">The Seven Samurai</option>-->

    <div class="form-group">
        <label for="curso">Curso (debe existir en BD, su código) *</label>
        <select name="id_course" class="form-control">
            <?php foreach( $rowCursos as $var => $curso ): ?>
            <option
            name="<?php echo $curso['id_course'] ?>"
            value="<?php echo $curso['id_course'] ?>"
                <?php
                if ($edit) {
                if( $class['id_course'] == $curso['id_course'] ) : ?> selected="selected" <?php endif; ?>
                <?php } ?>
            >
                <?php echo $curso['id_course'].' '. $curso['name'] ?>

            </option>
        <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label for="schedule">Programación (debe existir en BD, su código) *</label>
        <select name="id_schedule" class="form-control">
            <?php foreach( $rowSchedules as $var => $schedule ): ?>
                <option
                        name="<?php echo $schedule['id_schedule'] ?>"
                        value="<?php echo $schedule['id_schedule'] ?>"
                    <?php
                    if ($edit) {
                        if( $class['id_schedule'] == $schedule['id_schedule'] ) : ?> selected="selected" <?php endif; ?>
                    <?php } ?>
                >
                    <?php echo $schedule['id_schedule'].' '. $schedule['time_start'].' '. $schedule['day'] ?>

                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="form-group">
        <label for="name">Nombre</label>
        <input  type="text" name="name" value="<?php echo htmlspecialchars($edit ? $class['name'] : '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="nombre" class="form-control" id="nombre">
    </div>

    <div class="form-group">
        <label for="color">Color</label>
        <input  type="text" name="color" value="<?php echo htmlspecialchars($edit ? $class['color'] : '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="estado" class="form-control" id="estado">
    </div>

    <div class="form-group text-center">
        <label></label>
        <button type="submit" class="btn btn-warning" >Guardar <span class="glyphicon glyphicon-send"></span></button>
    </div>            
</fieldset>
