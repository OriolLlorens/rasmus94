<fieldset>
    <div class="form-group">
        <label for="codigo">Código matrícula *</label>
        <input type="text" name="codigo" value="<?php echo htmlspecialchars($edit ? $enrollment['id_enrollment'] : '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="codigo" class="form-control" disabled id = "codigo" >
    </div>
    <!--<div class="form-group">
        <label for="persona">Estudiante (debe existir en BD, su código) *</label>
          <input type="text" name="id_student" value="<?php /*echo htmlspecialchars($edit ? $enrollment['id_student'] : '', ENT_QUOTES, 'UTF-8'); */?>" placeholder="persona" class="form-control" required="required" id = "persona" >
    </div>-->
    <!--<div class="form-group">
        <label for="curso">Curso</label>
        <input  type="text" name="id_course" value="<?php /*echo htmlspecialchars($edit ? $enrollment['id_course'] : '', ENT_QUOTES, 'UTF-8'); */?>" placeholder="estado" class="form-control" id="estado">
    </div>-->

    <div class="form-group">
        <label for="student">Estudiante seleccion de la BD, su código) *</label>
        <select name="id_student" class="form-control">
            <?php foreach( $rowEstudiantes as $var => $estudiante ): ?>
                <option name="<?php echo $estudiante['id'] ?>"
                        value="<?php echo $estudiante['id'] ?>"
                    <?php
                    if ($edit) {
                        if( $enrollment['id_student'] == $estudiante['id'] ) : ?> selected="selected" <?php endif; ?>
                    <?php } ?>
                >
                    <?php echo $estudiante['id'].' '. $estudiante['name'].' '. $estudiante['surname'] ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label for="curso">Curso (debe existir en BD, su código) *</label>
        <select name="id_course" class="form-control">
            <?php foreach( $rowCursos as $var => $curso ): ?>
                <option
                        name="<?php echo $curso['id_course'] ?>"
                        value="<?php echo $curso['id_course'] ?>"
                    <?php
                    if ($edit) {
                        if( $enrollment['id_course'] == $curso['id_course'] ) : ?> selected="selected" <?php endif; ?>
                    <?php } ?>
                >
                    <?php echo $curso['id_course'].' '. $curso['name'] ?>

                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label for="estado">Estado</label>
        <input  type="text" name="status" value="<?php echo htmlspecialchars($edit ? $enrollment['status'] : '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="0/1" class="form-control" id="estado">
    </div>

    <div class="form-group text-center">
        <label></label>
        <button type="submit" class="btn btn-warning" >Guardar <span class="glyphicon glyphicon-send"></span></button>
    </div>            
</fieldset>
