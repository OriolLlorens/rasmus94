<fieldset>
    <div class="form-group">
        <label for="codigo">Código Horario *</label>
        <input type="text" name="codigo" value="<?php echo htmlspecialchars($edit ? $schedule['id_schedule'] : '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="codigo" class="form-control" disabled id = "codigo" >
    </div>

    <div class="form-group">
        <label for="student">Clase seleccione de la BD, su código) *</label>
        <select name="id_class" class="form-control">
            <?php foreach( $rowClases as $var => $clase ): ?>
                <option name="<?php echo $clase['id_class'] ?>"
                        value="<?php echo $clase['id_class'] ?>"
                    <?php
                    if ($edit) {
                        if( $schedule['id_class'] == $clase['id_class'] ) : ?> selected="selected" <?php endif; ?>
                    <?php } ?>
                >
                    <?php echo $clase['id_class'].' '. $clase['name'].' '. $clase['color'] ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label for="time_start">Inicio</label>
        <input  type="time" name="time_start" value="<?php echo htmlspecialchars($edit ? $schedule['time_start'] : '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="..." class="form-control" id="time_start">
    </div>
    <div class="form-group">
        <label for="time_end">Fin</label>
        <input  type="time" name="time_end" value="<?php echo htmlspecialchars($edit ? $schedule['time_end'] : '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="..." class="form-control" id="time_end">
    </div>
    <div class="form-group">
        <label for="day">Día</label>
        <input  type="date" name="day" value="<?php echo htmlspecialchars($edit ? $schedule['day'] : '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="..." class="form-control" id="day">
    </div>


    <div class="form-group text-center">
        <label></label>
        <button type="submit" class="btn btn-warning" >Guardar <span class="glyphicon glyphicon-send"></span></button>
    </div>            
</fieldset>
