<fieldset>

    <!-- CURSOS DISPONIBLES -->
    <div class="form-group">
        <label for="curso">Seleccione curso *</label>
        <select name="id_course" class="form-control">
            <?php foreach( $rowCursos as $var => $curso ): ?>
                <option
                        name="<?php echo $curso['id_course'] ?>"
                        value="<?php echo $curso['id_course'] ?>"
                    <?php
/*                    if ($edit) {
                        if( $class['id_course'] == $curso['id_course'] ) : */?><!-- selected="selected" <?php /*endif; */?>
                    --><?php /*} */?>

                    <?php echo $curso['id_course'].' '. $curso['name'] ?>

                </option>
            <?php endforeach; ?>
        </select>
    </div>
   <!-- <div class="form-group">
        <label for="student">Estudiante (debe existir en BD, su código) *</label>-->
        <input type="hidden" name="id_student"
               value="<?php echo htmlspecialchars($_SESSION['id_student'], ENT_QUOTES, 'UTF-8'); ?>"
               class="form-control">
   <!-- </div>-->

    <!--<div class="form-group">
        <label for="status">Curso</label>-->
        <input  type="hidden" name="status" value="1" class="form-control">
    <!--</div>-->






    <div class="form-group text-center">
        <label></label>
        <button type="submit" class="btn btn-warning" >Guardar <span class="glyphicon glyphicon-send"></span></button>
    </div>            
</fieldset>
