<fieldset>

   <div class="form-group">
        <label for="name">Nombre *</label>
        <input type="text" name="name"
        value="<?php echo htmlspecialchars($edit ? $course['name'] : '', ENT_QUOTES, 'UTF-8'); ?>"
        placeholder="name" class="form-control" required="required" id="name">
    </div>
    <div class="form-group">
        <label for="descripcion">Descripción *</label>
        <input type="text" name="description"
        value="<?php echo htmlspecialchars($edit ? $course['description'] : '', ENT_QUOTES, 'UTF-8'); ?>"
        placeholder="descripcion" class="form-control" required="required" id = "descripcion" >
    </div>

    <div class="form-group">
        <label for="date_start">Inicio</label>
        <input type="date" name="date_start"
        value="<?php echo htmlspecialchars(($edit) ? $course['date_start'] : '', ENT_QUOTES, 'UTF-8'); ?>"
        placeholder="Inicio" class="form-control" id="date_start">
    </div>
    <div class="form-group">
        <label for="date_end">Fin</label>
        <input type="date" name="date_end"
               value="<?php echo htmlspecialchars(($edit) ? $course['date_end'] : '', ENT_QUOTES, 'UTF-8'); ?>"
               placeholder="Fin" class="form-control" id="date_end">
    </div>
    <div class="form-group">
        <label for="active">Activo *</label>
        <input type="text" name="active"
               value="<?php echo htmlspecialchars($edit ? $course['active'] : '', ENT_QUOTES, 'UTF-8'); ?>"
               placeholder="0/1" class="form-control" required="required" id = "active" >
    </div>



    <div class="form-group text-center">
        <label></label>
        <button type="submit" class="btn btn-warning" >Guardar <span class="glyphicon glyphicon-send"></span></button>
    </div>            
</fieldset>
