<?php
class DAOCourses {
    /**
     *
     */
    public function __construct() {
        self::conectar();
    }
    private static function conectar()     {

        $bbdd = mysqli_connect(DB_HOST,DB_USER, DB_PASSWORD,DB_NAME);
        if (mysqli_connect_error()) {
            printf("Error conectando a la base de datos: %s\n",mysqli_connect_error());
            exit();
        }
        $bbdd->set_charset("utf8"); //cambiar el conjunto de caracteres a utf8
        return $bbdd;
    }
    
    private static function desconectar($bbdd)
    {
        mysqli_close($bbdd);
    }
    
    public static function comprobarUsuarioAdmin($login,$clave) {
        $bbdd = DAOCourses::conectar();
        $result = FALSE;
        
        if ($st = mysqli_prepare($bbdd, "SELECT * FROM usuarios WHERE usuario=? and clave=? and admin=1")) {
            mysqli_stmt_bind_param($st,"ss",$login,$clave);
            mysqli_stmt_execute($st);
            
            $result=mysqli_stmt_fetch($st);
            
            DAOCourses::desconectar($bbdd);
        }
        
        return $result;
    }
    
    public static function obtenerUsuarios() {
        $bbdd = DAOCourses::conectar();
        $usuarios= [];
        if ($rs = mysqli_query($bbdd,"SELECT *  FROM usuarios")) {
            while ($fila = mysqli_fetch_assoc($rs)) {
                array_push($usuarios, $fila);
            }
        }
        DAOCourses::desconectar($bbdd);
        return $usuarios;
    }

    public static function obtenerUsuariosPorFiltro($filtro, $filtroValor) {
        $bbdd = DAOCourses::conectar();
        $result = [];
        $str="SELECT * FROM usuarios";
        if ($filtroValor==null){
        }
        else {
            $str.=" WHERE ".$filtro." LIKE '%".trim($filtroValor)."%' ";
            //$str="SELECT * FROM usuarios WHERE ".$filtro." LIKE '%Lala%'";
        }
        if ($rs = mysqli_query($bbdd, $str )) {
            while ($fila = mysqli_fetch_assoc($rs)) {
                array_push($result, $fila);
            }
        }
        DAOCourses::desconectar($bbdd);
        return $result;
    }

    public static function obtenerCursosPorFiltro($filtro, $filtroValor) {
        $bbdd = DAOCourses::conectar();
        $result = [];
        $str="SELECT * FROM courses";
        if ($filtroValor==null){
        }
        else {
            $str.=" WHERE ".$filtro." LIKE '%".trim($filtroValor)."%' ";
            //$str="SELECT * FROM usuarios WHERE ".$filtro." LIKE '%Lala%'";
        }
        if ($rs = mysqli_query($bbdd, $str )) {
            while ($fila = mysqli_fetch_assoc($rs)) {
                array_push($result, $fila);
            }
        }
        DAOCourses::desconectar($bbdd);
        return $result;
    }

    public static function obtenerItemsPorFiltro($table, $filtro, $filtroValor) {
        $bbdd = DAOCourses::conectar();
        $result = [];
        $str="SELECT * FROM ".$table;
        if ($filtroValor==null){
        }
        else {
            $str.=" WHERE ".$filtro." LIKE '%".trim($filtroValor)."%' ";
            //$str="SELECT * FROM usuarios WHERE ".$filtro." LIKE '%Lala%'";
        }
        if ($rs = mysqli_query($bbdd, $str )) {
            while ($fila = mysqli_fetch_assoc($rs)) {
                array_push($result, $fila);
            }
        }
        DAOCourses::desconectar($bbdd);
        return $result;
    }
    public static function itemsPorFiltroYWhere($table, $fieldWhere, $where, $filtro, $filtroValor) {
        $bbdd = DAOCourses::conectar();
        $result = [];
        $str="SELECT * FROM ".$table;
        if ($fieldWhere==null){
            if ($filtroValor == null) {

            }
            else {
                $str .= " WHERE " . $filtro . " LIKE '%" . trim($filtroValor) . "%' ";
            }
        } else {
            if ($filtroValor == null) {
                    $str .= " Where " . $fieldWhere . " LIKE '%" . trim($where) . "%' ";
            } else {
                $str .= " WHERE " . $filtro . " LIKE '%" . trim($filtroValor) . "%' ";
                $str .= " AND id_student LIKE '%" . trim($where) . "%' ";
            }
        }
        if ($rs = mysqli_query($bbdd, $str )) {
            while ($fila = mysqli_fetch_assoc($rs)) {
                array_push($result, $fila);
            }
        }
        DAOCourses::desconectar($bbdd);
        return $result;
    }

    public static function obtenerListadoCursos() {
        
        $bbdd = DAOCourses::conectar();
        
        $lista= [];
        
        if ($result = mysqli_query($bbdd,"SELECT id_course, name, description, date_start, date_end, active  FROM courses")) {
            while ($fila = mysqli_fetch_array($result)) {
                array_push($lista, $fila);
            }
            
        }

        DAOCourses::desconectar($bbdd);
        
        return $lista;
    }
    
    public static function insertarCurso($name, $description, $date_start, $date_end, $active) {
        $bbdd = DAOCourses::conectar();
        $result = FALSE;
        if ($st = mysqli_prepare($bbdd, "INSERT INTO courses (id_course, name, description, date_start, date_end, active) VALUES (NULL,?,?,?,?,?)")) {
            mysqli_stmt_bind_param($st,"sdis",$name, $description, $date_start, $date_end, $active);
            mysqli_stmt_execute($st);
            $result=$st->affected_rows > 0;
            DAOCourses::desconectar($bbdd);
        }
        
        return $result;
    }

    public static function obtenerMatriculoaPorCodigo($cod) {
        $bbdd = DAOCourses::conectar();
        $result = null;
        if ($con = mysqli_prepare($bbdd, "SELECT * FROM enrollment WHERE id_enrollment=?")) {
            mysqli_stmt_bind_param($con, ”i”, $cod);
            mysqli_stmt_execute($con);
            $result = mysqli_stmt_fetch($con);
            DAOCourses::desconectar($bbdd);
            //mysqli_stmt_close($consulta);
        }
        return $result;
    }

    public static function obtenerMatriculasPorEstudiante($id) {
        $bbdd = DAOCourses::conectar();
        $result = null;
        $lista= [];
        /*
         * id_enrollment	id_student	id_course	status	id_course	name	description	date_start	date_end	active
            1 	            1 	        1 	        1 	    1 	Autocad 	diseño asistido 	2022-11-26 	2022-12-20 	1
            4 	            1 	        3 	        1 	    3 	Pov-Ray 	diseño artístico 	2023-08-26 	2023-10-20 	1
            2 	            1 	        5 	        1 	    5 	INE 	estadística 	2023-01-02 	2023-12-20 	1
        */
        if ($result = mysqli_query($bbdd,"SELECT * FROM enrollment e INNER JOIN courses c on c.id_course = e.id_course WHERE e.id_student='{$id}'")) {
            while ($fila = mysqli_fetch_array($result)) {
                array_push($lista, $fila);
            }
        }
        DAOCourses::desconectar($bbdd);
        return $lista;
    }
    public static function obtenerCursosPorEstudiante($id) {
        $bbdd = DAOCourses::conectar();
        $result = null;
        $lista= [];
        /*
         * id_enrollment	id_student	id_course	status	id_course	name	description	date_start	date_end	active
            1 	            1 	        1 	        1 	    1 	Autocad 	diseño asistido 	2022-11-26 	2022-12-20 	1
            4 	            1 	        3 	        1 	    3 	Pov-Ray 	diseño artístico 	2023-08-26 	2023-10-20 	1
            2 	            1 	        5 	        1 	    5 	INE 	estadística 	2023-01-02 	2023-12-20 	1
        */
        if ($result = mysqli_query($bbdd,"SELECT * FROM enrollment e INNER JOIN courses c on c.id_course = e.id_course WHERE e.id_student='{$id}'")) {
            while ($fila = mysqli_fetch_array($result)) {
                array_push($lista, $fila);
            }
        }
        DAOCourses::desconectar($bbdd);
        return $lista;
    }
    public static function obtenerHorariosClasesPorEstudiante( $fieldWhere, $where, $filtro, $filtroValor) {
        $bbdd = DAOCourses::conectar();
        $result = null;
        $lista= [];
        /*
         *  id_enrollment`
            id_student
            id_course
            status------------------
            id_course
            name
            description
            date_format(date_start, "%d-%m-%Y") AS fecha
            date_end
            active------------------
            id_class
            id_teacher
            id_course
            id_schedule
            name
            color--------------------
            id_schedule
            id_class
            time_start
            time_end
            day
        $qry="SELECT *, c.name as nameC FROM enrollment e INNER JOIN courses c on c.id_course = e.id_course INNER JOIN class cl on
        cl.id_course=c.id_course INNER JOIN schedule s on s.id_class=cl.id_class WHERE e.id_student=1";
            */
           $qry="SELECT *, c.name as nameC FROM ";
           //$qry="SELECT * FROM ";
           $qry=$qry."enrollment e INNER JOIN courses c ";
           $qry=$qry."on c.id_course = e.id_course ";
           $qry=$qry."INNER JOIN class cl on ";
           $qry=$qry."cl.id_course=c.id_course ";
           $qry=$qry."INNER JOIN schedule s on ";
           $qry=$qry."s.id_class=cl.id_class ";
           //$qry=$qry."WHERE e.id_student='{$where}'";

        if ($fieldWhere==null){
            if ($filtroValor == null) {
            }
            else {
                $qry .= " WHERE " . $filtro . " LIKE '%" . trim($filtroValor) . "%' ";
            }
        } else {
            if ($filtroValor == null) {
                $qry=$qry."WHERE e.id_student='{$where}'";
                //$str .= " Where " . $fieldWhere . " LIKE '%" . trim($where) . "%' ";
            } else {
                $qry .= " WHERE " . $filtro . " LIKE '%" . trim($filtroValor) . "%' ";
                $qry .= " AND id_student LIKE '%" . trim($where) . "%' ";
            }
        }

        if ($result = mysqli_query($bbdd, $qry)) {
            while ($fila = mysqli_fetch_array($result)) {
                array_push($lista, $fila);
            }
        }
        DAOCourses::desconectar($bbdd);
        return $lista;
    }
    public static function obtenerTodosHorariosClasesPorEstudiante() {
        $bbdd = DAOCourses::conectar();
        $result = null;
        $lista= [];

        $qry="SELECT * FROM ";
        $qry=$qry."enrollment e INNER JOIN courses c ";
        $qry=$qry."on c.id_course = e.id_course ";
        $qry=$qry."INNER JOIN class cl on ";
        $qry=$qry."cl.id_course=c.id_course ";
        $qry=$qry."INNER JOIN schedule s on ";
        $qry=$qry."s.id_class=cl.id_class ";
        //$qry=$qry."WHERE e.id_student='{$id}'";
        if ($result = mysqli_query($bbdd, $qry)) {
            while ($fila = mysqli_fetch_array($result)) {
                array_push($lista, $fila);
            }
            return $lista;
        }
        DAOCourses::desconectar($bbdd);
        return $lista;
    }

    public static function obtenerCalendario() {

        $qry = "SELECT sc.id_schedule, cl.name, cl.color, c.description, sc.day, sc.time_start, sc.time_end  FROM students s 
    INNER JOIN enrollment e ON s.id = e.id_student
    INNER JOIN courses c ON e.id_course = c.id_course
    INNER JOIN class cl ON c.id_course = cl.id_course
    INNER JOIN schedule sc ON cl.id_schedule = sc.id_schedule
    WHERE s.id = " . $_SESSION["id_student"];//["id"];
        $lista= [];
        $bbdd = DAOCourses::conectar();
        //$req = $bbdd->prepare($sql);
        //$result->execute();
        if ($result = mysqli_query($bbdd, $qry)) {
            while ($fila = mysqli_fetch_array($result)) {
                array_push($lista, $fila);
            }
            DAOCourses::desconectar($bbdd);
            return $lista;
        }
        //$events = $req->fetchAll();
        return null;
    }
}
?>