<?php
class AccesoBD {
    /**
     *
     */
    public function __construct() {
        self::conectar();
    }
    private static function conectar()     {

        $bbdd = mysqli_connect(DB_HOST,DB_USER, DB_PASSWORD,DB_NAME);
        if (mysqli_connect_error()) {
            printf("Error conectando a la base de datos: %s\n",mysqli_connect_error());
            exit();
        }
        return $bbdd;
    }
    
    private static function desconectar($bbdd)
    {
        mysqli_close($bbdd);
    }
    
    public static function comprobarUsuarioAdmin($login,$clave) {
        $bbdd = AccesoBD::conectar();
        $result = FALSE;
        
        if ($st = mysqli_prepare($bbdd, "SELECT * FROM usuarios WHERE usuario=? and clave=? and admin=1")) {
            mysqli_stmt_bind_param($st,"ss",$login,$clave);
            mysqli_stmt_execute($st);
            
            $result=mysqli_stmt_fetch($st);
            
            AccesoBD::desconectar($bbdd);
        }
        
        return $result;
    }
    
    public static function obtenerUsuarios() {
        $bbdd = AccesoBD::conectar();
        $usuarios= [];
        if ($rs = mysqli_query($bbdd,"SELECT *  FROM usuarios")) {
            while ($fila = mysqli_fetch_assoc($rs)) {
                array_push($usuarios, $fila);
            }
        }
        AccesoBD::desconectar($bbdd);
        return $usuarios;
    }

    public static function obtenerUsuariosPorFiltro($filtro, $filtroValor) {
        $bbdd = AccesoBD::conectar();
        $result = [];
        $str="SELECT * FROM usuarios";
        if ($filtroValor==null){
        }
        else {
            $str.=" WHERE ".$filtro." LIKE '%".trim($filtroValor)."%' ";
            //$str="SELECT * FROM usuarios WHERE ".$filtro." LIKE '%Lala%'";
        }
        if ($rs = mysqli_query($bbdd, $str )) {
            while ($fila = mysqli_fetch_assoc($rs)) {
                array_push($result, $fila);
            }
        }
        AccesoBD::desconectar($bbdd);
        return $result;
    }

    public static function obtenerProductosPorFiltro($filtro, $filtroValor) {
        $bbdd = AccesoBD::conectar();
        $result = [];
        $str="SELECT * FROM productos";
        if ($filtroValor==null){
        }
        else {
            $str.=" WHERE ".$filtro." LIKE '%".trim($filtroValor)."%' ";
            //$str="SELECT * FROM usuarios WHERE ".$filtro." LIKE '%Lala%'";
        }
        if ($rs = mysqli_query($bbdd, $str )) {
            while ($fila = mysqli_fetch_assoc($rs)) {
                array_push($result, $fila);
            }
        }
        AccesoBD::desconectar($bbdd);
        return $result;
    }

    public static function obtenerItemsPorFiltro($table, $filtro, $filtroValor) {
        $bbdd = AccesoBD::conectar();
        $result = [];
        $str="SELECT * FROM ".$table;
        if ($filtroValor==null){
        }
        else {
            $str.=" WHERE ".$filtro." LIKE '%".trim($filtroValor)."%' ";
            //$str="SELECT * FROM usuarios WHERE ".$filtro." LIKE '%Lala%'";
        }
        if ($rs = mysqli_query($bbdd, $str )) {
            while ($fila = mysqli_fetch_assoc($rs)) {
                array_push($result, $fila);
            }
        }
        AccesoBD::desconectar($bbdd);
        return $result;
    }

    public static function obtenerListadoProductos() {
        
        $bbdd = AccesoBD::conectar();
        
        $productos= [];
        
        if ($resultado = mysqli_query($bbdd,"SELECT codigo, descripcion, precio, existencias  FROM productos")) {
            while ($fila = mysqli_fetch_array($resultado)) {
                array_push($productos, $fila);
            }
            
        }
        
        AccesoBD::desconectar($bbdd);
        
        return $productos;
    }
    
    public static function insertarProducto($descripcion,$precio,$existencias) {
        
        
        $bbdd = AccesoBD::conectar();
        $result = FALSE;
        
        if ($st = mysqli_prepare($bbdd, "INSERT INTO productos (codigo,descripcion,precio,existencias,imagen) VALUES (NULL,?,?,?,?)")) {
            mysqli_stmt_bind_param($st,"sdis",$descripcion,$precio,$existencias);
            mysqli_stmt_execute($st);
            
            $result=$st->affected_rows > 0;
            
            AccesoBD::desconectar($bbdd);
        }
        
        return $result;
    }

    public static function obtenerPedidoPorCodigo($cod) {
        $bbdd = AccesoBD::conectar();
        $result = null;
        if ($con = mysqli_prepare($bbdd, "SELECT * FROM pedidos WHERE codigo=?")) {
            mysqli_stmt_bind_param($con, ”i”, $cod);
            mysqli_stmt_execute($con);
            $result = mysqli_stmt_fetch($con);
            AccesoBD::desconectar($bbdd);
            //mysqli_stmt_close($consulta);
        }
        return $result;
    }

    public static function obtenerDetallesPorPedido($codigo) {
        $bbdd = AccesoBD::conectar();
        $detalles= [];
        if ($resultado = mysqli_query($bbdd,"SELECT *  FROM `detalle` WHERE  `codigo_pedido` = ".$codigo)) {
            while ($fila = mysqli_fetch_array($resultado)) {
                array_push($detalles, $fila);
            }
        }
        AccesoBD::desconectar($bbdd);
        return $detalles;
    }
}
?>